#include "bmp.h"

void filter(int height, int width, RGBTRIPLE image[height][width]);